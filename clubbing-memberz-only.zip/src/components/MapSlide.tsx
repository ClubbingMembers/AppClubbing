import React, { useState } from 'react';
import { 
  MapPin, 
  Navigation, 
  Compass, 
  Info, 
  Star, 
  Search, 
  ZoomIn, 
  ZoomOut,
  Map as MapIcon,
} from 'lucide-react';
import { MusicalEvent } from '../types';

interface MapSlideProps {
  events: MusicalEvent[];
  onSelectEvent: (eventId: string) => void;
  theme?: string;
}

export const MapSlide: React.FC<MapSlideProps> = ({
  events,
  onSelectEvent,
  theme,
}) => {
  const [hoveredEvent, setHoveredEvent] = useState<MusicalEvent | null>(null);
  
  // Clean Southern Italy events filter
  const isSouthernItalyEvent = (id: string) => {
    return [
      'no-art-puglia',
      'badawi-puglia',
      'viva-festival',
      'crx-festival',
      'circoloco-grottella',
      'masseria-wave',
      'iperibleo',
      'opera-festival',
      'zamna-sardinia',
      'sonora-festival'
    ].includes(id);
  };

  const filteredEventsForMap = events.filter(ev => isSouthernItalyEvent(ev.id));

  const getCountdownText = (timestamp: number) => {
    const diff = timestamp - Date.now();
    if (diff <= 0) {
      return 'LIVE';
    }
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    return `-${days}g ${hours}h`;
  };
  const [activeEvent, setActiveEvent] = useState<MusicalEvent>(() => {
    return filteredEventsForMap.find(ev => ev.id === 'no-art-puglia') || filteredEventsForMap[0];
  });
  const [zoomLevel, setZoomLevel] = useState<number>(3); // 1-5 simulated zoom level

  const isLight = theme === 'light';

  // Specific highly-optimized Google Maps query mapper for 1:1 local town pinning
  const getGoogleMapsQuery = (event: MusicalEvent) => {
    switch (event.id) {
      case 'no-art-puglia':
        return 'Parco Archeologico di Egnazia, Fasano, Brindisi, Puglia, Italy';
      case 'badawi-puglia':
        return 'Fasano, Brindisi, Puglia, Italy';
      case 'viva-festival':
        return 'Locorotondo, Bari, Puglia, Italy';
      case 'crx-festival':
        return 'Grottaglie, Taranto, Puglia, Italy';
      case 'circoloco-grottella':
        return 'Masseria Grottella, Grottaglie, Taranto, Puglia, Italy';
      case 'masseria-wave':
        return 'Lequile, Lecce, Puglia, Italy';
      case 'iperibleo':
        return 'Palazzolo Acreide, Siracusa, Sicilia, Italy';
      case 'opera-festival':
        return 'Milo, Catania, Sicilia, Italy';
      case 'zamna-sardinia':
        return 'Baja Sardinia, Sassari, Sardegna, Italy';
      default:
        return `${event.venue}, ${event.location}`;
    }
  };

  // Specific 1:1 Southern Italy coordinate mapper
  const getCoordinates = (event: MusicalEvent) => {
    switch (event.id) {
      case 'no-art-puglia': return { x: 74, y: 38 };
      case 'badawi-puglia': return { x: 74, y: 36 };
      case 'viva-festival': return { x: 76, y: 41 };
      case 'crx-festival': return { x: 77, y: 46 };
      case 'circoloco-grottella': return { x: 76.5, y: 47.5 };
      case 'masseria-wave': return { x: 84, y: 55 };
      case 'iperibleo': return { x: 47, y: 89 };
      case 'opera-festival': return { x: 48, y: 81 };
      case 'zamna-sardinia': return { x: 16, y: 28 };
      default: return null;
    }
  };

  const handleSelectLocalEvent = (ev: MusicalEvent) => {
    setActiveEvent(ev);
  };

  return (
    <div id="slide-map" className={`relative w-full flex flex-col p-4 font-sans ${
      isLight ? 'text-slate-900 bg-white' : 'text-white bg-[#070b13]'
    }`}>
      
      {/* Design accents (hidden on smaller screens to maximize space) */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none hidden md:block">
        <div className={`absolute top-8 bottom-8 left-8 right-8 border ${isLight ? 'border-black/5' : 'border-white/5'}`} />
      </div>

      {/* Top Slide Indicator */}
      <div className="w-full flex justify-between items-center border-b pb-2 mb-4 shrink-0 transition-colors duration-200 border-slate-200/50 md:border-transparent">
        <div className="font-mono text-[10px] tracking-widest text-[#f43f5e] uppercase font-bold flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-[#f43f5e]" />
          <span>03 // LOCATION</span>
        </div>
        <div className={`font-mono text-[9px] tracking-widest uppercase ${isLight ? 'text-black/40' : 'text-white/40'}`}>
          SATELLITE POSITION 1:1
        </div>
      </div>

      {/* Slide Title & Description */}
      <div className="z-10 shrink-0 mb-4">
        <h2 className={`font-display font-black text-2xl md:text-3xl uppercase tracking-tight ${
          isLight ? 'text-slate-800' : 'text-white'
        }`}>
          LOCATION
        </h2>
        <p className={`font-sans font-normal text-xs md:text-sm max-w-xl mt-1.5 leading-relaxed ${
          isLight ? 'text-slate-600' : 'text-white/70'
        }`}>
          Esplora tutti i club e i festival estivi sulla mappa satellitare 1:1 del Sud Italia. Fai clic su un'area per visualizzare i confini, le città vicine e le coordinate reali.
        </p>
      </div>

      {/* Main Flow Content */}
      <div className="z-10 flex flex-col gap-5 w-full">
        
        {/* Events flow list */}
        <div className="flex flex-col space-y-3">
          <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border self-start ${
            isLight ? 'bg-black/5 border-black/10 text-slate-800' : 'bg-white/5 border-white/10 text-white/70'
          }`}>
            <Compass className="w-3 h-3 text-[#f43f5e]" />
            <span className="font-mono text-[9px] tracking-wider font-bold">GEOLOCALIZZAZIONE ATTIVA (SUD ITALIA)</span>
          </div>

          {/* Vertical flowing list of event locations */}
          <div className="space-y-1.5">
            {filteredEventsForMap.map((event) => {
              const isSelected = activeEvent.id === event.id;
              const isHovered = hoveredEvent?.id === event.id;

              return (
                <button
                  key={event.id}
                  type="button"
                  onClick={() => handleSelectLocalEvent(event)}
                  onMouseEnter={() => setHoveredEvent(event)}
                  onMouseLeave={() => setHoveredEvent(null)}
                  className={`w-full text-left p-2.5 rounded-xl border text-[11px] font-sans transition-all flex items-center justify-between cursor-pointer ${
                    isSelected
                      ? (isLight 
                          ? 'bg-gradient-to-r from-[#f43f5e]/15 to-[#f43f5e]/5 border-[#f43f5e] translate-x-1 font-semibold' 
                          : 'bg-[#f43f5e]/15 border-[#f43f5e] translate-x-1 font-semibold')
                      : isHovered
                      ? (isLight ? 'bg-slate-100 border-slate-300' : 'bg-slate-900 border-white/20')
                      : (isLight ? 'bg-slate-50 border-slate-200 hover:border-slate-300 shadow-sm' : 'bg-[#121824]/50 border-white/5 hover:border-white/10')
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${isSelected ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}`} />
                    <div className="min-w-0">
                      <div className={`font-bold uppercase flex items-center gap-1 truncate ${isLight ? 'text-slate-800' : 'text-white'}`}>
                        <span>{event.name}</span>
                        {event.isFavorite && (
                          <Star className="w-2.5 h-2.5 text-yellow-500 fill-yellow-500 shrink-0" />
                        )}
                      </div>
                      <div className={`text-[9px] font-mono truncate ${isLight ? 'text-slate-500' : 'text-white/50'}`}>
                        {event.venue} &bull; {event.location}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-1.5 shrink-0 ml-2">
                    <span className="font-mono text-[7.5px] font-semibold bg-[#f43f5e]/15 text-[#f43f5e] px-1 py-0.5 rounded border border-[#f43f5e]/10 tracking-tighter select-none">
                      {getCountdownText(event.timestamp)}
                    </span>
                    <Navigation className="w-3 h-3 text-[#f43f5e] shrink-0" />
                  </div>
                </button>
              );
            })}
          </div>

          <div className={`pt-2.5 border-t font-mono text-[9px] flex items-center gap-2 ${
            isLight ? 'text-slate-500 border-slate-200' : 'text-white/40 border-white/5'
          }`}>
            <Info className="w-3.5 h-3.5 text-[#f43f5e] shrink-0" />
            <span>Seleziona un club o festival per localizzarlo in tempo reale sulla mappa.</span>
          </div>
        </div>

        {/* Clean satellite view container - ALWAYS placed at the bottom */}
        <div className="relative h-[280px] w-full flex flex-col justify-between bg-[#0b0f19] rounded-2xl border border-white/10 overflow-hidden shrink-0 mt-2">
          
          {/* Dynamic Map Satellite View Canvas / Google Maps Iframe Rendering */}
          <div className="flex-grow flex-1 relative w-full h-full overflow-hidden flex items-center justify-center bg-[#070b13]">
            <iframe
              src={`https://maps.google.com/maps?q=${encodeURIComponent(getGoogleMapsQuery(activeEvent))}&t=k&z=${12 + zoomLevel}&ie=UTF8&iwloc=&output=embed`}
              className="absolute inset-0 w-full h-full border-0 rounded-2xl z-10 opacity-90"
              allowFullScreen={false}
              loading="lazy"
              referrerPolicy="no-referrer"
              title={`Google Map Satellite for ${activeEvent.name}`}
            />
          </div>

          {/* Coordinates overlay stats footer */}
          <div className="h-9 bg-[#0f1424] border-t border-white/10 px-4 flex items-center justify-between z-40 text-white/50 font-mono text-[8px] shrink-0">
            <div>GOOGLE SATELLITE RADAR • REAL-TIME MAPPING</div>
            <div className="uppercase">PIN POINTED AT {activeEvent.location.split(',')[0]}</div>
          </div>

        </div>

      </div>

      {/* Slide footer summary */}
      <div className={`font-mono text-[9px] tracking-wider flex flex-wrap justify-between items-center gap-3 z-10 border-t pt-3 mt-4 shrink-0 ${
        isLight ? 'text-slate-500 border-slate-200' : 'text-white/40 border-white/5'
      }`}>
        <div>VISUALIZZAZIONE SATELLITARE INTEGRATA</div>
        <div className="flex gap-2.5 items-center">
          <span className="flex items-center gap-1"><MapIcon className="w-3 h-3 text-[#f43f5e]" /> Sud Italia</span>
          <span className="w-1 h-1 bg-slate-300 rounded-full" />
          <span>Coordinate Scalate 1:1</span>
        </div>
      </div>
    </div>
  );
};
