import React from 'react';
import { ChevronRight, Clock, MapPin, Tag, Star } from 'lucide-react';
import { MusicalEvent } from '../types';

interface TimelineSlideProps {
  events: MusicalEvent[];
  onSelectEvent: (eventId: string) => void;
  theme?: string;
}

export const TimelineSlide: React.FC<TimelineSlideProps> = ({
  events,
  onSelectEvent,
  theme,
}) => {
  const isLight = theme === 'light';

  // Sort events by timestamp
  const sortedEvents = [...events].sort((a, b) => a.timestamp - b.timestamp);

  const getCountdownText = (timestamp: number) => {
    const diff = timestamp - Date.now();
    if (diff <= 0) {
      return 'LIVE';
    }
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    return `-${days}g ${hours}h`;
  };

  return (
    <div id="slide-timeline" className={`relative w-full p-4 font-sans ${
      isLight ? 'text-slate-900 bg-white' : 'text-white bg-[#070b13]'
    }`}>
      
      {/* Design accents */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none hidden md:block">
        <div className={`absolute top-8 bottom-8 left-8 right-8 border ${isLight ? 'border-black/5' : 'border-white/5'}`} />
      </div>

      {/* Top Slide Indicator (Flow-based to avoid overlap) */}
      <div className="w-full flex justify-between items-center border-b pb-2 mb-4 shrink-0 transition-colors duration-200 border-slate-200/50 md:border-transparent">
        <div className="font-mono text-[10px] tracking-widest text-[#f43f5e] uppercase font-bold flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-[#f43f5e]" />
          <span>02 // DIARIO ESTIVO</span>
        </div>
        <div className={`font-mono text-[9px] tracking-widest uppercase ${isLight ? 'text-black/40' : 'text-white/40'}`}>
          SELECT TO EXPLORE
        </div>
      </div>

      {/* Slide Title & Subtitle */}
      <div className="z-10 shrink-0">
        <h2 className={`font-display font-black text-xl md:text-3xl uppercase tracking-tight ${
          isLight ? 'text-slate-800' : 'text-white'
        }`}>
          DIARIO
        </h2>
        <p className={`font-sans font-normal text-[11px] md:text-sm max-w-xl mt-1.5 leading-relaxed ${
          isLight ? 'text-slate-600' : 'text-white/70'
        }`}>
          La cronologia temporale da luglio a fine estate. Clicca su un evento per aprire i dettagli completi, line-up e acquisto ticket.
        </p>
      </div>

      {/* Vertical Timeline List Container */}
      <div className="my-5 z-10 flex-grow relative w-full pr-1">
        
        {/* Timeline main vertical line stem */}
        <div className="absolute top-0 bottom-0 left-[14px] w-0.5 bg-gradient-to-b from-[#f43f5e] via-purple-500 to-emerald-500 rounded-full" />

        <div className="space-y-4">
          {sortedEvents.map((event) => {
            return (
              <button
                key={event.id}
                id={`timeline-node-${event.id}`}
                onClick={() => onSelectEvent(event.id)}
                className="w-full text-left flex items-start gap-2.5 group focus:outline-none transition-transform duration-300 active:scale-[0.99] hover:translate-x-0.5"
              >
                {/* Visual Circle Indicator along vertical path */}
                <div className="relative shrink-0 flex items-center justify-center pt-2">
                  <div className={`w-7 h-7 rounded-full border-2 border-[#f43f5e]/80 group-hover:border-slate-400 transition-all flex items-center justify-center shadow-[0_0_12px_rgba(244,63,94,0.25)] z-20 ${
                    isLight ? 'bg-white' : 'bg-slate-900'
                  }`}>
                    <Clock className={`w-3 h-3 ${isLight ? 'text-[#f43f5e]' : 'text-white'}`} />
                  </div>
                  {/* Subtle pulse under nodes */}
                  <div className="absolute w-7 h-7 rounded-full bg-[#f43f5e]/10 -z-10 animate-pulse" />
                </div>

                {/* Event Information Card */}
                <div className={`flex-grow p-3 border rounded-xl shadow-sm transition-all duration-300 w-full min-w-0 overflow-hidden ${
                  isLight
                    ? 'bg-slate-50 border-slate-200 group-hover:border-[#f43f5e]/80 group-hover:bg-amber-50/10'
                    : 'bg-[#121824]/60 border-white/5 group-hover:border-white/20 group-hover:bg-slate-900/40'
                }`}>
                  <div className="flex flex-col gap-2">
                    <div className="space-y-1">
                      {/* Date Indicator badge and Countdown */}
                      <div className="flex justify-between items-center gap-2 select-none">
                        <span className="font-mono text-[9px] font-bold text-[#f43f5e] tracking-wider uppercase">
                          {event.date}
                        </span>
                        <span className="font-mono text-[8.5px] font-semibold bg-[#f43f5e]/10 text-[#f43f5e] px-1.5 py-0.5 rounded border border-[#f43f5e]/15 shrink-0">
                          {getCountdownText(event.timestamp)}
                        </span>
                      </div>
                      
                      <h3 className={`font-display font-bold text-xs md:text-sm leading-snug flex items-center gap-1.5 flex-wrap whitespace-normal ${
                        isLight ? 'text-slate-800' : 'text-white'
                      }`}>
                        <span className="break-words">{event.name}</span>
                        {event.isFavorite && (
                          <Star className="w-3 h-3 text-yellow-500 fill-yellow-500 shrink-0" />
                        )}
                      </h3>

                      <p className={`font-mono text-[10px] flex items-start gap-1 mt-1 leading-snug whitespace-normal ${
                        isLight ? 'text-slate-500' : 'text-white/50'
                      }`}>
                        <MapPin className="w-3 h-3 text-[#f43f5e] shrink-0 mt-0.5" />
                        <span className="block min-w-0 flex-1 break-words">
                          <strong className={`block font-bold tracking-tight ${isLight ? 'text-slate-750' : 'text-white/90'}`}>{event.venue}</strong>
                          <span className={`text-[9px] block ${isLight ? 'text-slate-500' : 'text-white/40'}`}>{event.location}</span>
                        </span>
                      </p>
                    </div>

                    <div className={`flex items-center justify-between border-t pt-1.5 mt-1 ${isLight ? 'border-slate-200' : 'border-white/5'}`}>
                      <span className={`text-[8px] font-mono px-2 py-0.5 rounded uppercase ${
                        isLight 
                          ? 'bg-slate-100 border border-slate-200 text-slate-700' 
                          : 'bg-white/5 border border-white/10 text-white/80'
                      }`}>
                        {event.genre}
                      </span>
                      
                      <div className="text-[10px] text-[#f43f5e] font-mono flex items-center gap-0.5 opacity-85 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all">
                        <span>Vedi</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </div>
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Slide footer summary */}
      <div className={`font-mono text-[9px] tracking-wider flex flex-wrap justify-between items-center gap-2.5 z-10 border-t pt-3 mt-4 shrink-0 ${
        isLight ? 'text-slate-500 border-slate-200' : 'text-white/40 border-white/5'
      }`}>
        <div>DIARIO ESTIVO • MULTI-SCROLL DISATTIVATO</div>
        <div className="flex gap-2 items-center">
          <span className="flex items-center gap-1"><Tag className="w-3 h-3 text-[#f43f5e]" /> Estate 2026</span>
        </div>
      </div>
    </div>
  );
};
